#include <stdio.h>

struct stackNode{
	int data;
	struct stackNode *nextPtr;
};

typedef struct stackNode StackNode;
typedef StackNode *StackNodePtr;
void push(StackNodePtr *topPtr, int value);
int pop(StackNodePtr *topPtr);

int main(){
	StackNodePtr sPtr;
	
	push(&sPtr,1);
	push(&sPtr,2);
	push(&sPtr,3);
	push(&sPtr,4);
	push(&sPtr,5);
	
	printf("son=%d\n",pop(&sPtr));
	printf("son=%d\n",pop(&sPtr));
	printf("son=%d\n",pop(&sPtr));
	printf("son=%d\n",pop(&sPtr));
	printf("son=%d\n",pop(&sPtr));
		
	return 0;
}



void push(StackNodePtr *topPtr, int value){

	StackNodePtr newPtr;

	newPtr=(StackNodePtr) malloc(sizeof(StackNode));
	
	if (newPtr!=NULL){
		(*newPtr).data=value;
		(*newPtr).nextPtr=*topPtr;
		(*topPtr) = newPtr;
	}

}

int pop(StackNodePtr *topPtr){
	
	int value; 
	StackNodePtr tempPtr; //to free the top node.
	
	value=(**topPtr).data;
	tempPtr=*topPtr;
	*topPtr=(**topPtr).nextPtr;
	free(tempPtr);
	return value;
	
}

