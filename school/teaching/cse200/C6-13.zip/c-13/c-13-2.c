#include <stdio.h>
#include <stdlib.h>
struct queueNode{
	int data;
	struct queueNode *nextPtr;
};

typedef struct queueNode QueueNode;
typedef QueueNode *QueueNodePtr;

void enqueue(QueueNodePtr *headPtr, QueueNodePtr *tailPtr, int value );
int dequeue(QueueNodePtr *headPtr);
int main(){
	QueueNodePtr headPtr=NULL,tailPtr=NULL;
	
	enqueue(&headPtr,&tailPtr,1);
	enqueue(&headPtr,&tailPtr,2);
	enqueue(&headPtr,&tailPtr,3);
	enqueue(&headPtr,&tailPtr,4);
	enqueue(&headPtr,&tailPtr,5);
	
	printf("cikti=%d\n",dequeue(&headPtr));
	printf("cikti=%d\n",dequeue(&headPtr));
	printf("cikti=%d\n",dequeue(&headPtr));
	printf("cikti=%d\n",dequeue(&headPtr));
	printf("cikti=%d\n",dequeue(&headPtr));
	

}


void enqueue(QueueNodePtr *headPtr, QueueNodePtr *tailPtr, int value ){

	QueueNodePtr newPtr;
	newPtr = (QueueNodePtr) malloc(sizeof(QueueNode));
	if (newPtr!=NULL){
	
		(*newPtr).data=value;
		(*newPtr).nextPtr=NULL;
	
		if (*headPtr==NULL){
			*headPtr=newPtr;
		}
		else {
			(**tailPtr).nextPtr=newPtr;
			*tailPtr = newPtr;
		}
	}



}


int dequeue(QueueNodePtr *headPtr){

	int value;
	QueueNodePtr tempPtr;
	
	value=(**headPtr).data;
	tempPtr=*headPtr;
	*headPtr=(**headPtr).nextPtr;
	free(tempPtr);
	return value;
	
}