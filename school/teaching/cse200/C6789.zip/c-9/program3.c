
#include <stdio.h>

int main(){
struct student{
	//char gender;
	int age;
	char name[20];
	double gpa;

};

printf("%d\n",sizeof(struct student));

return 0;
}