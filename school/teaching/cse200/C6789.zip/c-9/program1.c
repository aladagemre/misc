#include <stdio.h>

int main(){
	
	int i=5;
	char name[20]="ali veli";
	double x = 2.3;
	FILE *fptr;
	
	fptr=fopen("fileOpened.txt","w");
	fprintf(fptr,"%3d\n",i);
	//Sonraki fprintf kaldigin yerden devam ettirecektir.
	fprintf(fptr,"%s\n",name);
	fprintf(fptr,"%3.2lf\n",x);
	fputs("Selamlar...",fptr);
	fputc('!',fptr);
	fputc('\n',fptr);
	fclose(fptr);
	printf("\n\n\n");
	fptr=fopen("fileOpened.txt","r");
	fscanf(fptr, "%d",&i);
	fscanf(fptr, "%s",name);//sadece ali'yi okur!!! veliyi okumaz.
	fscanf(fptr, "%f",&x); //satır satır okuyor.
	printf("%d %s %f\n",i,name,x);
	fclose(fptr);

	fptr=fopen("fileOpened.txt","r");
	fscanf(fptr, "%d%s%f",&i,name,&x);
	printf("%d %s %f\n",i,name,x);
	fclose(fptr);

}