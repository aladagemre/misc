#include <stdio.h>



int main(){
int ia[]={14,20000};  //integer array.
FILE fptr;
fptr=fopen("diger.txt","w");

fwrite(ia, sizeof(int),2,fptr);

fclose(fptr);

fptr=fopen("diger.txt","r");
int i1;
fread(&i1,sizeof(int),1,fptr); //14 alır. Eğer 1 yerine 2 deseydik 14 ile 20000 i birleştirilmiş halini verecekti.(2lik tabanda)
fclose(fptr);

return 0;
}