
#include <stdio.h>
#include <string.h>

int main(){
char s[]="This,is,a,sentence";

char *d=",";
char *t;

t=strtok(s,d);

while (t!=NULL){
	printf("%s\n",t);
	t=strtok( NULL,d);
}

return 0;
}