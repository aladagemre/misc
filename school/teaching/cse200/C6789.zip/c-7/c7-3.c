#include <stdio.h>

int main(){
char a[]="Emre";
char b[10];

b=a;

printf("%s",b);


return 0;

}