#include <stdio.h>

struct student {
		char *name;
		int age;
		struct student *afriend;
	};

int main(){
	
	struct student a,b;
	//want to make b, friend of a.
	
		a.name="Ali Veli";
		b.name="Selami";
		a.age=49;
		b.age=50;
		
		a.afriend=&b;
		b.afriend=&a;

	printf("%s\n",(*(a.afriend)).name);
	printf("%s",(*((*(a.afriend)).afriend)).name);
	printf("\n");

return 0;
}