#include <stdio.h>
int main(){

union number{
	int x;
	double y;
} ;

union number a;

a.x=255;
a.y=81.0;

printf("x=%d\n",a.x);
printf("y=%f\n",a.y);



a.x=255;


printf("x=%d\n",a.x);
printf("y=%f\n",a.y); //bozuk basması gerekiyordu ama eski degerini korudu??? :(




return 0;

}