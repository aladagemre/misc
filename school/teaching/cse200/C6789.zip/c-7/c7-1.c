#include <stdio.h>

struct student {
	char *name;
	int age;
	};

typedef struct student Student;


int main(){
Student class[20];
	//want to make b, friend of a.


class[3].name="Emre";

printf("%s\n",class[3].name);


	return 0;
}