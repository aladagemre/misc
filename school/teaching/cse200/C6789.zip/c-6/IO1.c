#include <stdio.h>

int main(){
float a=123;

printf("%.2g\n",a);
return 0;
}