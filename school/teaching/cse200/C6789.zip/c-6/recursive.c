#include <stdio.h>
/*
Fibonacci
fn=fn-1 + fn-2

Recursive calculation
Performance is very low.
*/

int f(int n);
int main(){
	printf("5. eleman= %d\n\n",f(5));
	return 0;
}

int f(int n){
	
	if (n==0)		
		return 1;
	else if (n==1)
		return 1;
	else
		return f(n-1)+f(n-2);
}

