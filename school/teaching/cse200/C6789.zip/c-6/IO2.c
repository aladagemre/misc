#include <stdio.h>

int main(){
float a=123.304;

printf("%09.3f\n",a);
return 0;
}