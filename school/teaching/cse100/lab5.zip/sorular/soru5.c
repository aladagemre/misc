/*Soru 5. Print the greatest common divisor(obeb)  of two integers given by the user.
Iki sayinin ebobunu yani en buyuk ortak bolenini bulacagiz.

1) ebob, en kucuk sayidan daha buyuk olamaz ama en kucuk sayiya esit olabilir. ebob<=min yani.
2) ebob, 2'den kucuk olamaz. ebob>=2
*/
#include<stdio.h>


int main()
{
  int i,x,y,min,gcd;
  
  printf("Enter your integers :");
  scanf("%d%d",&x,&y);
  //En kucuk sayiyi tespit ediyoruz.
  min=x;
  if(x>y)
    min=y;

  for(i=2;i<=min;i++) //Burada 2'den min'e kadar saydiriyoruz.(madde1)
    if(x%i == 0 && y%i == 0) //Eger ebob adayi sayi "i", hem x'i hem de y'yi tam bolebiliyorsa
      gcd=i; //Ebob odur.

	/*Yukaridaki donguyu min'e kadar surdurur. Break(donguden cikma) olayi yoktur.Min'e kadar tarar cunku ileride sartlari saglayan daha buyuk bir sayinin gelecegini dusunur.
Ornegin: 
24,36
2 saglar, 3 saglar, 4 saglar, 6 saglar, 12 saglar... Eger break kullansaydik 2'yi gorunce cikardi. Halbuki
biz 12'ye ulasmak istiyoruz.
*/
  printf("gcd is %d\n\n",gcd); //En sonunda elde edilen ebob'u yazdir.
  return 0;
}