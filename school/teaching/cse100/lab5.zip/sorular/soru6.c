/*Soru 6. Print the perfect numbers between 1 and 1000 that are even. (An integer is said to be a perfect number if its factors, including 1 (but not the number itself), sum to the number. For example, 6=1+2+3)

1 ile 1000 arasindaki cift mukemmel sayilari yazdir. Mukemmel sayi, kendisi haric carpanlarinin toplami
kendisine esit olan sayidir. Orn: 6=1.2.3 bir mukemmel sayi; ama su degil:  24!=1+2+3+4+6+8+12*/

#include<stdio.h>


int main()
{
  int i,j,sum;
  
  printf("Even perfect numbers between 1 and 1000 :\n");
  for(i=2;i<=1000;i+=2) //1 cift olmadigi icin 2'den baslatiyoruz.1000'e kadar, 2 arttırarak (i+=2)
  {
    sum=0; //Her sayi icin toplami farkli farkli hesaplayacagimiz icin basta 0'liyoruz.
    for(j=1;j<i;j++) //Sayiya kadar (sayi haric) saydiriyoruz.
      if(i%j == 0)  //Eger saydirilen sayac j sayinin bir asal carpaniysa,
	sum+=j; //Toplam degiskenine ekle bu sayiyi.
    if(sum == i) //Icteki for dongusu(asal carpan tarama islemi) bittiginde bu carpanlarin toplami sayiya esitse
      printf("%d\n",i); //sayiyi yazdir.
  }
return 0;
}