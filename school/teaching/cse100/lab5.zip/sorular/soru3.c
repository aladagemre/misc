/*Soru 3. Print the numbers between 100 and 999 whose sum of cubes of the digits is equal to the number itself.

100 ile 999 arasinda olan, rakamlarinin kupleri toplami kendisine esit olan sayilari listele.

*/
#include<stdio.h>

int main()
{
  int i,d1,d2,d3;

  for(i=100;i<1000;i++) //100..999 tariyoruz
  {
    //haneleri parcalayalim.
    d1=i/100; 
    d2=i/10%10;
    d3=i%10;
	    if((d1*d1*d1+d2*d2*d2+d3*d3*d3) == i) //Eger her hanenin kupleri toplami i'ye yani sayiya esitse
		printf("%d ",i); //sayiyi bastir.
  }


return 0;

}
