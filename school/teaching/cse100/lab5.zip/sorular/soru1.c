/* Soru 1. Print the prime numbers between 100 and 999 whose sum of digits are even. 
100 ile 999 arasindaki, rakamlari toplami cift olan asal sayilari yazdirmamizi istiyor.
O zaman, once 100 ile 999 arasindaki sayilari tarayalim, asal oldugunu tespit ettiklerimizi
"bu sayi cift mi?" testine sokalim. 

Asal sayi olup olmadigini bulmak icin sayiyi, kendinden onceki sayilara bolmeyi denemeliyiz.
Mesela 19:
2'ye bolunmez, 3'e bolunmez, 4'e bolunmez, ... , 9'a bolunmez, 10'a bolunmez , ... ,18'e bolunmez.

Burada 2'den 18'e kadar bolmeyi deneriz. Eger hicbirisi bolemiyorsa bu sayi asaldir deriz.

Algoritmada bir iyilestirme yapacak olursak, sayinin yarisina kadar taramamiz yeterli olur.
Zira 100 sayisini denetliyor olsak, 50'den sonraki sayilarin hicbirisi 100'u zaten bolemeyecektir.
O halde 50'den(yarisindan) ileri gitmenin anlami yoktur. O yuzden j<=i/2 yaziyor.

*/
#include<stdio.h>

int main()
{
  int i,j,d1,d2,d3,simdiye_kadar_bolen_cikmadi;

  for(i=100;i<1000;i++) //100 ile 999 arasi. i<=999 da olurdu.
  {
    simdiye_kadar_bolen_cikmadi=1; //Burada her sayi icin bu degiskeni 1 yapiyoruz.

    for(j=2;j<=i/2;j++) //2'den baslayarak sayinin yarisina kadar taratiyoruz.
      if(i%j == 0) //Eger bu taranan sayilardan herhangi biri buyuk sayiyi boluyorsa, bu sayi asal degildir.
	simdiye_kadar_bolen_cikmadi=0; /*Simdiye kadar bolen cikmadi degiskenini olumsuz, yani 0 yaparak
	 "sayinin siciline leke suruyoruz." Boylece sayinin sicili kirliyse bunun bir asal sayi olmadigini
	 anliyoruz.*/

    if(simdiye_kadar_bolen_cikmadi==1) //Eger tum bu tarama sonucunda hicbir sayi buyuk sayiyi bolemediyse
    {
      //Basamaklarina ayiriyoruz.
      d1=i/100;
      d2=(i/10)%10;
      d3=i%10;

      if((d1+d2+d3)%2==0) //Eger basamaklarinin toplami cift ise
	printf("%d\t",i); //O BUYUK(ASIL[100..999]) sayiyi yazdir.
    } //if bitti.

  } //for bitti

return 0;

}