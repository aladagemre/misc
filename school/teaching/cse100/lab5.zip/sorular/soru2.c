/*Soru 2. Print the Fibonacci numbers between 2000 and 5000 whose sum of digits are even.
Degeri 2000 ile 5000 arasinda olan fibonacci sayilarindan, rakamlari toplami cift olanlari
bulun diyor. Fibonacci sayilari 0 1 ile baslar ve kurali soyledir:

0 1 (0+1) (1+1) 1+(1+1)
0 1   1      2     3		5	8	13	21	34...

Yani son iki elemani toplayarak bir sonraki elemani olusturabiliyoruz.
Bu durumda
f_once=3
f_sonra=5
iken, 
f_once=5
f_sonra=8 yapmak istiyoruz. Yani sonra=>once olacak, f_sonra degiskeni yeni deger alacak. Bunu da gecici
degisken olmadan yapamiyoruz. Yoksa degiskenler birbirinin uzerine yazilir.




*/
#include <stdio.h>
int main(){
  long f_once=0, f_sonra=1, temp;
  int counter,d1,d2,d3,d4,dt;


  for (counter=3; f_sonra<5000 ; counter++){ //f_sonra'nn yani sayinin degeri 5000'den kucuk oldugu surece devam
    temp=f_sonra; //Once son degeri bir kenara yazalim.
    f_sonra=f_sonra+f_once; //Yeni son elemani olusturalim. (f_once ve f_sonra'yi toplayarak.)
    f_once=temp; //Onceki degiskene "eski f_sonra" degerini yazalim. Boylece ilerleme saglandi.
    if ((f_sonra>=2000) & (f_sonra<=5000)){ //Eger son elemanin degeri istedigimiz araliktaysa
	//Sayiyi parcala hanelere.
	d1=f_sonra/1000;
	dt=f_sonra%1000;
	d2=dt/100;
	dt=dt%100;
	d3=dt/10;
	dt=dt%10;
	d4=dt;
	if ((d1+d2+d3+d4)%2 == 0) //Eger rakamlari toplami cift ise
		printf("%d \n\n",f_sonra); //Son elemani bastir. Orn: 4181 cikacak sadece
    }
	  
  }

  return 0;

}