/*Soru 4. Print the least common multiple(ekok) of two integers given by the user.(ekok)

Iki sayinin ekokunu hesaplayan programi yaz. 
1) Bu sayi, bildirilen iki sayiya da tam bolunmelidir
2) Bu sayi x*y den daha buyuk olamaz.
3) Bu sayi iki sayinin en buyugunden daha kucuk olamaz.
4) Bu sartlari saglayan mumkun olan en kucuk sayidir.

*/

#include<stdio.h>


int main()
{
  int i,x,y,max;
  
  printf("Enter your integers :");
  scanf("%d%d",&x,&y);
  //Sayilarin buyugunu belirleyelim.
  max=y; //Once y'nin en buyuk oldugunu varsayalim.
  if(x>y) //Sonra eger x>y ise, 
    max=x; //en buyuk sayi x olur. (x=y ise max=y olarak kalir, zaten bir sey farketmez.)

  for(i=max;i<=x*y;i++) //2. ve 3. madde geregi en buyuk sayidan x*y'ye kadar saydiriyoruz.
    if(i%x == 0 && i%y == 0) //Eger i sayisi hem x'e hem de y'ye tam bolunuyorsa
    {
      printf("gcd is %d",i); //sayiyi bas
      break; //Donguyu sonlandir. Cunku zaten istedigimiz (4.madde) en kucuk sayiyi bulduk.
    }

  return 0;
}
